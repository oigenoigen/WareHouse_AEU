import sys
from PyQt5.QtWidgets import QWidget, QStackedLayout, QApplication
from autorizWidget import AutorizWidget
from chooseWidget import ChooseWidget
from entryWidget import EntryWidget
from getDbWidget import GetDbData


class MainWindow(QWidget):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.setFocus()
        self.currentLayout=QStackedLayout()
        autorizWidget=AutorizWidget(parent=self)
        self.currentLayout.addWidget(autorizWidget)#index 0
        chooseWidget = ChooseWidget(parent=self)
        self.currentLayout.addWidget(chooseWidget)  # index 1
        entryWidget=EntryWidget(parent=self)
        self.currentLayout.addWidget(entryWidget)#index 2
        getDbData=GetDbData(parent=self)
        self.currentLayout.addWidget(getDbData)#index 3
        self.currentLayout.setCurrentIndex(0)
        self.setLayout(self.currentLayout)
        self.setFocus()


        self.setGeometry(300, 300, 500, 250)
        self.setWindowTitle('AEU wire warehouse')

        self.show()



if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWindow()
    sys.exit(app.exec_())