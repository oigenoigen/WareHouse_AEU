from PyQt5.QtWidgets import QWidget, QPushButton, QLabel

class ChooseWidget(QWidget):
    def __init__(self,parent=None):
        super(ChooseWidget, self).__init__(parent)

        titleLabel=QLabel('Choose what to do',self)

        fillDbBut=QPushButton('Fill database',self)
        fillDbBut.clicked.connect(self.fillDbLayout)

        getFromDbButt=QPushButton('Get data from database',self)
        getFromDbButt.clicked.connect(self.getFromDbLayout)

        backButton = QPushButton('Back to authorization',self)
        backButton.clicked.connect(self.backButtonClicked)

        fillDbBut.move(205,120)
        getFromDbButt.move(180,160)
        backButton.move(340,0)
        titleLabel.move(210,10)


    def fillDbLayout(self):
        self.parent().currentLayout.setCurrentIndex(2)

    def getFromDbLayout(self):
        self.parent().currentLayout.setCurrentIndex(3)

    def backButtonClicked(self):
        self.parent().currentLayout.setCurrentIndex(0)

