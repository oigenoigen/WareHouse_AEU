from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QGridLayout

class AutorizWidget(QWidget):
    def __init__(self, parent=None):
        super(AutorizWidget, self).__init__(parent)

        titleLabel = QLabel('Authorization',self)

        self.autorizField = QLineEdit(self)
        self.autorizField.selectAll()
        self.autorizField.setFocus()
        self.autorizField.returnPressed.connect(self.validationOfAutorization)

        autorizLabel = QLabel('Scan Your barcode',self)

        titleLabel.move(220,10)
        self.autorizField.move(200,160)
        autorizLabel.move(210,140)

    def validationOfAutorization(self):
        if self.autorizField.text() == str(10017096):
            self.autorizField.setText('')
            self.parent().currentLayout.setCurrentIndex(1)
