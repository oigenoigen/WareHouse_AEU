from PyQt5.QtWidgets import QWidget, QLineEdit, QLabel, QPushButton, QSizePolicy
import dbConnection

class GetDbData(QWidget):
    def __init__(self,parent=None):
        super(GetDbData, self).__init__(parent)

        titleLabel=QLabel('Input material number to find article',self)

        materialLabel=QLabel('Material label',self)
        self.materialField=QLineEdit(self)
        self.materialField.returnPressed.connect(self.findArticle)

        identLabel=QLabel('Identification number',self)
        self.identField=QLineEdit(self)
        self.identField.returnPressed.connect(self.checkIdentifier)

        self.materialField.setReadOnly(False)
        self.identField.setReadOnly(True)

        self.materialField.selectAll()
        self.materialField.setFocus()

        delivLabel=QLabel('Delivery number',self)
        self.delivFieldLabel=QLabel('                                                        ',self)

        placeLabel = QLabel('Place number',self)
        self.placeFieldLabel = QLabel('                                                      ',self)


        backButton=QPushButton('Back to previous menu',self)
        backButton.clicked.connect(self.backButtonClicked)

        self.checkLabel=QLabel('                                                             ',self)#spaces are here because field stay too small

        titleLabel.move(110,10)
        backButton.move(340,0)

        materialLabel.move(30, 50)
        identLabel.move(30, 100)
        delivLabel.move(30, 150)
        placeLabel.move(30, 200)

        self.materialField.move(300, 50)
        self.identField.move(300, 100)
        self.delivFieldLabel.move(300, 150)
        self.placeFieldLabel.move(300, 200)

        self.checkLabel.move(350,220)


    def findArticle(self):
        #make DB check
        self.dbRow=self.parent().connection.readDb(self.materialField.text())
        if len(self.dbRow) == 6:
            self.delivFieldLabel.setText(self.dbRow[2])
            self.placeFieldLabel.setText(self.dbRow[3])
            self.materialField.setReadOnly(True)
            self.identField.setReadOnly(False)
            self.identField.setFocus()
            self.parent().connection.changeWireState(self.dbRow[0],self.dbRow[2])
        else:
            self.delivFieldLabel.setText('No data about this wire')
            self.placeFieldLabel.setText('No data about this wire')


    def checkIdentifier(self):
        #make DB check
        if self.identField.text() == self.dbRow[1]:
            self.parent().connection.deleteFromDb(self.dbRow[0], self.dbRow[2])
            self.identField.setReadOnly(True)
            self.materialField.setReadOnly(False)
            self.materialField.setText('')
            self.identField.setText('')
            self.placeFieldLabel.setText('')
            self.delivFieldLabel.setText('')
            self.materialField.setFocus()
        else:
            self.checkLabel.setText("Wrong!")

    def backButtonClicked(self):
        self.materialField.setText('')
        self.identField.setText('')
        self.placeFieldLabel.setText('')
        self.delivFieldLabel.setText('')
        self.materialField.setReadOnly(False)
        self.identField.setReadOnly(True)
        self.parent().currentLayout.setCurrentIndex(1)
