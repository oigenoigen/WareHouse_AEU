from PyQt5.QtWidgets import QWidget, QLabel, QLineEdit, QGridLayout
import dbConnection

class AutorizWidget(QWidget):
    def __init__(self, parent=None):
        super(AutorizWidget, self).__init__(parent)

        titleLabel = QLabel('Authorization',self)

        self.autorizField = QLineEdit(self)
        self.autorizField.setEchoMode(QLineEdit.Password)
        self.autorizField.selectAll()
        self.autorizField.setFocus()
        self.autorizField.returnPressed.connect(self.validationOfAutorization)

        autorizLabel = QLabel('Scan Your barcode',self)

        self.stateLabel=QLabel('                                             ',self)

        titleLabel.move(220,10)
        self.autorizField.move(200,160)
        autorizLabel.move(210,140)
        self.stateLabel.move(210,190)

    def validationOfAutorization(self):
        checkList=self.autorizField.text().split('$')
        if len(checkList)!=2:
            self.stateLabel.setText("Try again")
        else:
            self.parent().connection=dbConnection.DbConnection(checkList[0],checkList[1])
            if self.parent().connection.m_conn!=None:
                self.autorizField.setText('')
                self.stateLabel.setText("")
                self.parent().currentLayout.setCurrentIndex(1)
            else:
                self.stateLabel.setText("Wrong barcode!")