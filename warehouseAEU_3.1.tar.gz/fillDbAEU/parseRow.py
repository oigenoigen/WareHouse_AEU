def ParseRow(row):
    if len(row)!=0:
        tup=row[0]
        parsedRow=[x for x in tup]
        parsedRow[5]=parsedRow[5].strftime('%Y-%m-%d %H:%M:%S')
    else:
        parsedRow=[]
    return parsedRow