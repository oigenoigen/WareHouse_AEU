import mysql.connector as mariadb
from confRead import config_read
from parseRow import ParseRow
import datetime

class DbConnection():

    def __init__(self, user, password):
        self.m_conn=None
        try:
            self.m_conn=mariadb.connect(user=user, password=password, database='warehouseAEU')
            self.cursor=self.m_conn.cursor()
        except mariadb.DatabaseError:
            print("Wrong username or password (wrong barcode)")


    def writeToDb(self):
        conf = config_read()
        material=conf['dbValues']['material']
        identifier=conf['dbValues']['identifier']
        deliveryNumber=conf['dbValues']['delivery']
        place=conf['dbValues']['place']
        curDate=datetime.datetime.now()
        state='on place'

        self.cursor.execute("INSERT INTO wires (material,identificator,vendor_batch,place, state, date_and_time) VALUES ('%s','%s','%s','%s', '%s','%s')" % (material,identifier,deliveryNumber,place,state,curDate))
        self.m_conn.commit()



    def readDb(self, materialNumber):
        self.cursor.execute("SELECT * FROM wires WHERE material= '%s' ORDER BY vendor_batch LIMIT 1"% int(materialNumber))
        dbRow = self.cursor.fetchall()
        dbParsedRow=ParseRow(dbRow)


        return dbParsedRow

    def changeWireState(self,materialNumber,vendor_batch):
        curDate = datetime.datetime.now()

        state = 'changed'
        self.cursor.execute("UPDATE wires SET state='%s', date_and_time ='%s' WHERE material = '%s' AND vendor_batch = '%s'" % (state, curDate,materialNumber, vendor_batch))

        self.m_conn.commit()


    def deleteFromDb(self, materialNumber, vendor_batch):
        self.cursor.execute("DELETE FROM wires WHERE material='%s' AND vendor_batch='%s'"%(materialNumber,vendor_batch))

        self.m_conn.commit()
