from PyQt5.QtWidgets import QWidget, QLineEdit, QLabel, QPushButton, QGridLayout
import dbConnection
import configparser
import datetime

class EntryWidget(QWidget):
    def __init__(self,parent=None):
        super(EntryWidget, self).__init__(parent)
        #layout for enter data
        self.matField = QLineEdit(self)
        self.matField.selectAll()
        self.matField.setFocus()
        self.matField.returnPressed.connect(self.validationOfMaterial)

        self.identField = QLineEdit(self)
        self.identField.returnPressed.connect(self.validationOfIdentifier)

        self.delivField = QLineEdit(self)
        self.delivField.returnPressed.connect(self.validationOfDelivery)

        self.placeField = QLineEdit(self)
        self.placeField.returnPressed.connect(self.validationOfPlace)

        self.matField.setReadOnly(False)
        self.identField.setReadOnly(True)
        self.delivField.setReadOnly(True)
        self.placeField.setReadOnly(True)

        matLabel = QLabel('Here You have to enter material number',self)
        identLabel = QLabel('Here You have to enter identifier number',self)
        delivLabel = QLabel('Here You have to enter delivery number',self)
        placeLabel = QLabel('Here You have to enter place number',self)
        titleLabel=QLabel('Input data about wires',self)

        backButton=QPushButton('Back to previous menu',self)
        backButton.clicked.connect(self.backButtonClicked)

        titleLabel.move(190,10)

        matLabel.move(30,50)
        identLabel.move(30,100)
        delivLabel.move(30,150)
        placeLabel.move(30,200)

        self.matField.move(300,50)
        self.identField.move(300,100)
        self.delivField.move(300,150)
        self.placeField.move(300,200)

        backButton.move(340,0)

    def validationOfMaterial(self):
        if len(self.matField.text())==8:
            self.matField.setReadOnly(True)
            self.identField.setReadOnly(False)
            self.identField.selectAll()
            self.identField.setFocus()

    def validationOfIdentifier(self):
        if len(self.identField.text())==14:
            self.identField.setReadOnly(True)
            self.delivField.setReadOnly(False)
            self.delivField.selectAll()
            self.delivField.setFocus()

    def validationOfDelivery(self):
        if len(self.delivField.text())==10:
            self.delivField.setReadOnly(True)
            self.placeField.setReadOnly(False)
            self.placeField.selectAll()
            self.placeField.setFocus()

    def validationOfPlace(self):
        if len(self.placeField.text())==10:
            self.placeField.setReadOnly(True)
            config = configparser.ConfigParser()
            config['dbValues'] = {}
            config['dbValues']['material'] = self.matField.text()
            config['dbValues']['identifier'] = self.identField.text()
            config['dbValues']['delivery'] = self.delivField.text()
            config['dbValues']['place'] = self.placeField.text()

            with open('config.ini', 'w') as configfile:
                config.write(configfile)
                configfile.close()
            self.matField.setText('')
            self.identField.setText('')
            self.delivField.setText('')
            self.placeField.setText('')
            self.placeField.setReadOnly(True)
            self.matField.setReadOnly(False)
            self.matField.setFocus()

            self.parent().connection.writeToDb()
            #QCoreApplication.instance().quit()

    def backButtonClicked(self):
        self.matField.setText('')
        self.identField.setText('')
        self.delivField.setText('')
        self.placeField.setText('')
        self.placeField.setReadOnly(True)
        self.matField.setReadOnly(False)
        self.parent().currentLayout.setCurrentIndex(1)
