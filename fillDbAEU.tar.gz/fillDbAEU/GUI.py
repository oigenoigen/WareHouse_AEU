from tkinter import *
import dbConnection
import configparser


class gui(Tk):
    def __init__(self):
        Tk.__init__(self)
        self.initialize()
        self.mainloop()


    def initialize(self):

        self.title("Insert Your article")
        self.geometry('500x400+300+200')

        def callbackMaterial(*args):#fucking black magic
            #print(self.v.get())
            if len(self.matStVar.get())==8:#choose another way to check it
                self.materialValue=self.matStVar.get()
                #self.dataList=dbGetData.conn(self.v.get())#if i`m adding int() here, I get list AND None value
                self.identField = Entry(self, textvariable=self.identStVar)
                self.identField.place(x=100, y=150)
                self.identField.focus_set()

        def callbackIdent(*args):
            if len(self.identStVar.get())==14:
                self.identifierValue=self.identStVar.get()
                #self.TestLabel.config(text='Correct!')
            #else:
                #self.TestLabel.config(text='Wrong!')
                self.delivField = Entry(self, textvariable=self.delivStVar)
                self.delivField.place(x=100, y=200)
                self.delivField.focus_set()

        def callbackDeliv(*args):
            if len(self.delivStVar.get())==10:
                self.deliveryValue=self.delivStVar.get()
                #self.TestLabel.config(text='Correct!')
            #else:
                #self.TestLabel.config(text='Wrong!')
                self.placeField = Entry(self, textvariable=self.placeStVar)
                self.placeField.place(x=100, y=250)
                self.placeField.focus_set()

        def callbackPlace(*args):
            if len(self.placeStVar.get())==10:
                self.placeValue=self.placeStVar.get()
                config = configparser.ConfigParser()
                config['dbValues']={}
                config['dbValues']['material']=self.materialValue
                config['dbValues']['identifier']=self.identifierValue
                config['dbValues']['delivery']=self.deliveryValue
                config['dbValues']['place']=self.placeValue

                with open('config.ini', 'w') as configfile:
                    config.write(configfile)

                self.matStVar=None
                self.delivStVar=None
                self.identStVar=None
                self.placeStVar=None
                self.destroy()


        self.matStVar=StringVar()
        self.matStVar.trace_add("write",callbackMaterial)

        self.identStVar=StringVar()
        self.identStVar.trace_add("write", callbackIdent)

        self.delivStVar = StringVar()
        self.delivStVar.trace_add("write", callbackDeliv)

        self.placeStVar = StringVar()
        self.placeStVar.trace_add("write", callbackPlace)

        self.MatNumberField=Entry(self,textvariable=self.matStVar )
        self.MatNumberField.place(x=100,y=100)
        self.MatNumberField.focus_set()

