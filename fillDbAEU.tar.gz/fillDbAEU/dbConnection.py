import mysql.connector as mariadb
from confRead import config_read

class WriteToDB():

    def __init__(self):
        m_conn=mariadb.connect(user='sa', password='Prettl!@#4', database='warehouseAEU')
        cursor=m_conn.cursor()

        conf = config_read()
        material=conf['dbValues']['material']
        identifier=conf['dbValues']['identifier']
        deliveryNumber=conf['dbValues']['delivery']
        place=conf['dbValues']['place']

        cursor.execute("INSERT INTO wires (material,identifier,deliveryNumber,place) VALUES (%s,%s,%s,%s)" % (material,identifier,deliveryNumber,place))
        m_conn.commit()

        m_conn.close()


