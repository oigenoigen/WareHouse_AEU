import mysql.connector as mariadb

def conn(key):
    mariadb_connection=mariadb.connect(user='sa', password = 'Prettl!@#4', database = 'testdb')
    cursor=mariadb_connection.cursor()

    cursor.execute('SELECT * FROM indexes WHERE wavelength = %s'%(key))
    rez=cursor.fetchall()
    rez=str(rez)
    rez=rez.strip('[')
    rez = rez.strip(']')
    rez = rez.strip('(')
    rez = rez.strip(')')
    rez=rez.split(',')
    rez1=[x.strip(' ') for x in rez]
    fin=[x[1:-1] for x in rez1]
    fin.pop(0)###############eto prosto pizdec
    return fin