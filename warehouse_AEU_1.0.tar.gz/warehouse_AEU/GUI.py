from tkinter import *
import dbGetData


class gui(Tk):
    def __init__(self):
        Tk.__init__(self)
        self.initialize()
        self.mainloop()


    def initialize(self):

        self.title("Choose Your article")
        self.geometry('500x400+300+200')

        def callback(*args):#fucking black magic
            #print(self.v.get())
            if len(self.v.get())==3:#choose another way to check it
                self.dataList=dbGetData.conn(self.v.get())#if i`m adding int() here, I get list AND None value
                print(self.dataList)
                print((self.dataList[0]))
                self.TestField.focus_set()

        def callback1(*args):
            if self.v1.get()==self.dataList[0]:
                self.TestLabel.config(text='Correct!')
            else:
                self.TestLabel.config(text='Wrong!')


        self.v=StringVar()
        self.v.trace_add("write",callback)

        self.v1=StringVar()
        self.v1.trace_add("write", callback1)

        self.MatNumberField=Entry(self,textvariable=self.v )
        self.MatNumberField.place(x=100,y=100)
        self.MatNumberField.focus_set()

        self.TestField=Entry(self,textvariable=self.v1)
        self.TestField.place(x=100,y=200)

        self.TestLabel=Label(self,text='')
        self.TestLabel.place(x=300,y=200)