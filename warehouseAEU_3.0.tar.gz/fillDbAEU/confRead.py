import os
import configparser


def config_read():
    config=configparser.ConfigParser()

    if os.system('ls config.ini > /dev/null')==512:#printing resut of ls. Don`t know for now how to fix it
        print('no file!')
        #gui()
    elif os.system('ls config.ini > /dev/null')==0:
        pass
    else:
        print('something is wrong')

    config.read('config.ini')
    return config