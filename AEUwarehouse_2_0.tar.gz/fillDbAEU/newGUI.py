import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import QCoreApplication
import configparser
import dbConnection


class MainWindow(QWidget):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.setFocus()
        self.currentLayout=QStackedLayout()
        autorizWidget=AutorizWidget()
        self.currentLayout.addWidget(autorizWidget)#index 0
        chooseWidget = ChooseWidget()
        self.currentLayout.addWidget(chooseWidget)  # index 1
        entryWidget=EntryWidget()
        self.currentLayout.addWidget(entryWidget)#index 2
        getDbData=GetDbData()
        self.currentLayout.addWidget(getDbData)#index 3
        self.currentLayout.setCurrentIndex(0)
        self.setLayout(self.currentLayout)
        self.setFocus()


        self.setGeometry(300, 300, 500, 250)
        self.setWindowTitle('AEU wire warehouse')

        self.show()


class AutorizWidget(QWidget):
    def __init__(self):
        super().__init__()

        titleLabel=QLabel('Authorization')

        self.autorizField=QLineEdit()
        self.autorizField.selectAll()
        self.autorizField.setFocus()
        self.autorizField.textChanged.connect(self.validationOfAutorization)

        autorizLabel=QLabel('Scan Your barcode')

        autorizGrid=QGridLayout()
        autorizGrid.setSpacing(1)

        autorizGrid.addWidget(titleLabel,0,1)

        autorizGrid.addWidget(autorizLabel,2,0)
        autorizGrid.addWidget(self.autorizField,2,1)

        self.setLayout(autorizGrid)


    def validationOfAutorization(self):
        if self.autorizField.text() == str(10017096):
            self.autorizField.setText('')
            ex.currentLayout.setCurrentIndex(1)

class ChooseWidget(QWidget):
    def __init__(self):
        super().__init__()
        fillDbBut=QPushButton('Fill database')
        fillDbBut.clicked.connect(self.fillDbLayout)
        getFromDbButt=QPushButton('Get data from database')
        getFromDbButt.clicked.connect(self.getFromDbLayout)

        backButton = QPushButton('Back to authorization')
        backButton.clicked.connect(self.backButtonClicked)

        chooseGrid=QGridLayout()
        chooseGrid.setSpacing(1)

        chooseGrid.addWidget(backButton,0,2)

        chooseGrid.addWidget(fillDbBut,0,0)
        chooseGrid.addWidget(getFromDbButt,1,0)

        self.setLayout(chooseGrid)

    def fillDbLayout(self):
        ex.currentLayout.setCurrentIndex(2)

    def getFromDbLayout(self):
        ex.currentLayout.setCurrentIndex(3)

    def backButtonClicked(self):
        ex.currentLayout.setCurrentIndex(0)



class EntryWidget(QWidget):
    def __init__(self):
        super().__init__()
        #layout for enter data
        self.matField = QLineEdit()
        self.matField.selectAll()
        self.matField.setFocus()
        self.matField.textChanged.connect(self.validationOfMaterial)

        self.identField = QLineEdit()
        self.identField.textChanged.connect(self.validationOfIdentifier)

        self.delivField = QLineEdit()
        self.delivField.textChanged.connect(self.validationOfDelivery)

        self.placeField = QLineEdit()
        self.placeField.textChanged.connect(self.validationOfPlace)

        self.matField.setReadOnly(False)
        self.identField.setReadOnly(True)
        self.delivField.setReadOnly(True)
        self.placeField.setReadOnly(True)

        matLabel = QLabel('Here You have to enter material number')
        identLabel = QLabel('Here You have to enter identifier number')
        delivLabel = QLabel('Here You have to enter delivery number')
        placeLabel = QLabel('Here You have to enter place number')
        titleLabel=QLabel('Input data about wires')

        backButton=QPushButton('Back to previous menu')
        backButton.clicked.connect(self.backButtonClicked)

        enterGrid = QGridLayout()
        enterGrid.setSpacing(1)

        enterGrid.addWidget(backButton,0,2)

        enterGrid.addWidget(titleLabel,0,1)

        enterGrid.addWidget(matLabel, 1, 0)
        enterGrid.addWidget(self.matField, 1, 1)

        enterGrid.addWidget(identLabel, 2, 0)
        enterGrid.addWidget(self.identField, 2, 1)

        enterGrid.addWidget(delivLabel, 3, 0)
        enterGrid.addWidget(self.delivField, 3, 1)

        enterGrid.addWidget(placeLabel, 4, 0)
        enterGrid.addWidget(self.placeField, 4, 1)

        self.setLayout(enterGrid)

    def validationOfMaterial(self):
        if len(self.matField.text())==8:
            self.matField.setReadOnly(True)
            self.identField.setReadOnly(False)
            self.identField.selectAll()
            self.identField.setFocus()

    def validationOfIdentifier(self):
        if len(self.identField.text())==14:
            self.identField.setReadOnly(True)
            self.delivField.setReadOnly(False)
            self.delivField.selectAll()
            self.delivField.setFocus()

    def validationOfDelivery(self):
        if len(self.delivField.text())==10:
            self.delivField.setReadOnly(True)
            self.placeField.setReadOnly(False)
            self.placeField.selectAll()
            self.placeField.setFocus()

    def validationOfPlace(self):
        if len(self.placeField.text())==10:
            self.placeField.setReadOnly(True)
            config = configparser.ConfigParser()
            config['dbValues'] = {}
            config['dbValues']['material'] = self.matField.text()
            config['dbValues']['identifier'] = self.identField.text()
            config['dbValues']['delivery'] = self.delivField.text()
            config['dbValues']['place'] = self.placeField.text()

            with open('config.ini', 'w') as configfile:
                config.write(configfile)
                configfile.close()
            self.matField.setText('')
            self.identField.setText('')
            self.delivField.setText('')
            self.placeField.setText('')
            self.placeField.setReadOnly(True)
            self.matField.setReadOnly(False)
            self.matField.setFocus()

            conn=dbConnection.DbConnection()
            conn.writeToDb()
            #QCoreApplication.instance().quit()

    def backButtonClicked(self):
        self.matField.setText('')
        self.identField.setText('')
        self.delivField.setText('')
        self.placeField.setText('')
        self.placeField.setReadOnly(True)
        self.matField.setReadOnly(False)
        ex.currentLayout.setCurrentIndex(1)


class GetDbData(QWidget):
    def __init__(self):
        super().__init__()

        titleLabel=QLabel('Input material number to find article')

        materialLabel=QLabel('Material label')
        self.materialField=QLineEdit()
        self.materialField.textChanged.connect(self.findArticle)

        identLabel=QLabel('Identification number')
        self.identField=QLineEdit()
        self.identField.textChanged.connect(self.checkIdentifier)

        #self.materialField.setReadOnly(False)
        #self.identField.setReadOnly(True)

        self.materialField.selectAll()
        self.materialField.setFocus()

        delivLabel=QLabel('Delivery number')
        self.delivFieldLabel=QLabel('')

        placeLabel = QLabel('Place number')
        self.placeFieldLabel = QLabel('')

        backButton=QPushButton('Back to previous menu')
        backButton.clicked.connect(self.backButtonClicked)

        self.checkLabel=QLabel('')

        getDataGrid=QGridLayout()
        getDataGrid.setSpacing(1)

        getDataGrid.addWidget(titleLabel,0,1)

        getDataGrid.addWidget(materialLabel,1,0)
        getDataGrid.addWidget(self.materialField,1,1)

        getDataGrid.addWidget(identLabel,2,0)
        getDataGrid.addWidget(self.identField,2,1)

        getDataGrid.addWidget(delivLabel,3,0)
        getDataGrid.addWidget(self.delivFieldLabel,3,1)

        getDataGrid.addWidget(placeLabel,4,0)
        getDataGrid.addWidget(self.placeFieldLabel,4,1)

        getDataGrid.addWidget(backButton,0,2)

        getDataGrid.addWidget(self.checkLabel,4,2)

        self.setLayout(getDataGrid)


    def findArticle(self):
        #make DB check
        if len(self.materialField.text())==8:
            conn=dbConnection.DbConnection()
            self.dbRow=conn.readDb(self.materialField.text())
            if len(self.dbRow) == 4:
                self.delivFieldLabel.setText(self.dbRow[2])
                self.placeFieldLabel.setText(self.dbRow[3])
                self.materialField.setReadOnly(True)
                self.identField.setReadOnly(False)
                self.identField.setFocus()

    def checkIdentifier(self):
        #make DB check
        if self.identField.text() == self.dbRow[1]:
            self.checkLabel.setText("Correct!")
            self.identField.setReadOnly(True)
            self.materialField.setReadOnly(False)
        else:
            self.checkLabel.setText("Wrong!")

    def backButtonClicked(self):
        self.materialField.setText('')
        self.identField.setText('')
        self.placeFieldLabel.setText('')
        self.delivFieldLabel.setText('')
        ex.currentLayout.setCurrentIndex(1)




if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWindow()
    sys.exit(app.exec_())