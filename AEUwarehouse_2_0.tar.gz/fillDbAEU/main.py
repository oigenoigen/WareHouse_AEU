import GUI
import dbConnection

for i in range(2):
    #g=GUI.gui()
    c=dbConnection.WriteToDB()
