def ParseRow(row):
    stRow = str(row)
    stStriped = stRow.strip('[')
    stStriped1 = stStriped.strip(']')
    stStriped2 = stStriped1.strip('(')
    stStriped3 = stStriped2.strip(')')
    stStriped4 = stStriped3.split(',')
    stStriped5 = [x.strip(' ') for x in stStriped4]
    fin = [x[1:-1] for x in stStriped5]
    fin.pop(0)  ###############eto prosto pizdec
    return fin