import mysql.connector as mariadb
from confRead import config_read
from parseRow import ParseRow

class DbConnection():

    def __init__(self):
        self.m_conn=mariadb.connect(user='sa', password='Prettl!@#4', database='warehouseAEU')
        self.cursor=self.m_conn.cursor()

    def writeToDb(self):
        conf = config_read()
        material=conf['dbValues']['material']
        identifier=conf['dbValues']['identifier']
        deliveryNumber=conf['dbValues']['delivery']
        place=conf['dbValues']['place']

        self.cursor.execute("INSERT INTO wires (material,identifier,deliveryNumber,place) VALUES ('%s','%s','%s','%s')" % (material,identifier,deliveryNumber,place))
        self.m_conn.commit()

        self.m_conn.close()

    def readDb(self, materialNumber):
        self.cursor.execute('SELECT * FROM wires WHERE material= %s ORDER BY deliveryNumber LIMIT 1'% int(materialNumber))
        dbRow = self.cursor.fetchall()
        dbParsedRow=ParseRow(dbRow)

        self.m_conn.close()

        return dbParsedRow